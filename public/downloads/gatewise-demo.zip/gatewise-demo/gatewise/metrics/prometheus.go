// Package metrics exports Gatewise service statistics to a caller-owned
// Prometheus registry. It never registers with global/default registries.
package metrics

import (
	"fmt"
	"github.com/HN026/gatewise/operation"
	"github.com/prometheus/client_golang/prometheus"
	"reflect"
)

type Source interface{ Statistics() operation.Statistics }

type collector struct {
	queueDescriptors
	controllerControlRatio, controllerControlFailure, controllerWindowInterval, controllerWindowStart, controllerProfile, controllerSmoothed, controllerPending, controllerSparse, controllerExternal *prometheus.Desc
	workAdmitted, workRejected, workCompleted, workDuration                                                                                                                                           *prometheus.Desc
	budgetBytes, budgetLimit, budgetActive, budgetTracked, budgetTrackingLimit, budgetFallback, budgetExpired, budgetAttempts, budgetProposals, budgetRejected, budgetAdmitted                        *prometheus.Desc
	decisionInfo, proposals, signalState, signalValue, signalThreshold, signalTime, signalAccepted, signalDropped, signalFailures                                                                     *prometheus.Desc
	sharingDemand, sharingShares, sharingPause, sharingActive, sharingAdmissions                                                                                                                      *prometheus.Desc
	resolutions                                                                                                                                                                                       *prometheus.Desc
	tenantLimit, tenantTracked, tenantTrackingLimit, tenantActive, tenantExpired                                                                                                                      *prometheus.Desc
	controllerSamples, controllerRatio, controllerFailures, controllerTime, controllerDecision, controllerSaturated                                                                                   *prometheus.Desc
	service                                                                                                                                                                                           Source
	limit, minimum, maximum, reserved, active, info, admitted, rejected, completed, duration, adjustments                                                                                             *prometheus.Desc
}

// Register adds one service to registry. Service names must be unique within that
// registry. The caller owns the HTTP handler and can use promhttp.HandlerFor.
func Register(registry prometheus.Registerer, service Source) error {
	if registry == nil || service == nil || reflect.ValueOf(service).Kind() == reflect.Ptr && reflect.ValueOf(service).IsNil() {
		return fmt.Errorf("gatewise metrics: registry and service are required")
	}
	serviceName := service.Statistics().Name
	desc := func(name, help string, labels ...string) *prometheus.Desc {
		return prometheus.NewDesc("gatewise_"+name, help, labels, prometheus.Labels{"service": serviceName})
	}
	c := &collector{service: service, queueDescriptors: newQueueDescriptors(desc),
		controllerControlRatio: desc("controller_control_ratio", "Last control ratio: aggregate p90 for legacy, worst aggregate p90 or well-sampled tier p95 for stable."), controllerControlFailure: desc("controller_control_failure_fraction", "Last failure fraction used for control, including well-sampled tier failures for stable."),
		controllerWindowInterval: desc("controller_window_interval_seconds", "Current feedback interval, including stable profile local timing offset."), controllerWindowStart: desc("controller_window_started_timestamp_seconds", "Current feedback-window start; no evaluation is implied."),
		controllerProfile: desc("controller_info", "Selected bounded controller profile.", "profile"), controllerSmoothed: desc("controller_smoothed_ratio", "Stable profile EWMA of the selected normalized control ratio; zero before sufficient feedback."), controllerPending: desc("controller_pending_samples", "Current unevaluated window completions."), controllerSparse: desc("controller_sparse_window", "Last evaluation had fewer than configured minimum samples and held capacity."), controllerExternal: desc("controller_external_limit", "A matching signal ceiling constrained admission in the last evaluated window."),
		workAdmitted:        desc("work_admitted_total", "Admitted work by bounded integration kind.", "kind"),
		workRejected:        desc("work_rejected_total", "Admission rejections by bounded integration kind.", "kind"),
		workCompleted:       desc("work_completed_total", "Completed actual operation lifetimes.", "kind", "outcome"),
		workDuration:        desc("work_duration_seconds", "Duration through actual completion, including SQL stream/transaction lifetime.", "kind"),
		budgetBytes:         desc("resource_write_bytes_in_flight", "Reserved planned logical write bytes; includes short pre-admission reservations.", "budget"),
		budgetLimit:         desc("resource_write_bytes_limit", "Configured concurrent planned logical write-byte budget.", "budget"),
		budgetActive:        desc("resource_reservations_in_flight", "Active resource reservations; held until handler return.", "budget"),
		budgetTracked:       desc("resource_keys_tracked", "Bounded retained key entries; no key labels.", "budget"),
		budgetTrackingLimit: desc("resource_keys_tracking_limit", "Maximum retained key entries.", "budget"),
		budgetFallback:      desc("resource_key_fallback_in_flight", "Fallback reservations by bounded bucket.", "budget", "bucket"),
		budgetExpired:       desc("resource_keys_expired_total", "Idle key entries expired.", "budget"),
		budgetAttempts:      desc("resource_attempts_total", "Matched resource-policy evaluations.", "budget"),
		budgetProposals:     desc("resource_rejection_proposals_total", "Resource policy rejection proposals; observe mode still tracks actual occupancy.", "budget"),
		budgetRejected:      desc("resource_rejections_total", "Evaluations blocked by combined resource rules or metadata validation.", "budget"),
		budgetAdmitted:      desc("resource_admissions_total", "Resource reservations committed after all hard admission checks.", "budget"),
		decisionInfo:        desc("decision_engine_info", "Configured decision mode.", "mode"),
		proposals:           desc("signal_proposals_total", "Evaluated proposals; a limit proposal is not a counterfactual rejection.", "action"),
		signalState:         desc("signal_state", "Current cached signal state; one hot.", "signal", "state"),
		signalValue:         desc("signal_value", "Last observed value; inspect state before using.", "signal"),
		signalThreshold:     desc("signal_threshold", "Configured pressure threshold.", "signal"),
		signalTime:          desc("signal_observed_timestamp_seconds", "Measurement time; zero before observation.", "signal"),
		signalAccepted:      desc("signal_observations_total", "Accepted cache updates.", "signal"),
		signalDropped:       desc("signal_observations_dropped_total", "Discarded observations.", "signal", "reason"),
		signalFailures:      desc("signal_collection_failures_total", "Bounded collection failure reasons, no error text.", "signal", "reason"),
		sharingDemand:       desc("tenant_sharing_demanding_tenants", "Identified tenants with active or recent demand."),
		sharingShares:       desc("tenant_sharing_demand_shares", "Configured shares of tenants with active or recent demand."),
		sharingPause:        desc("tenant_sharing_borrowing_paused", "One while lending is paused after below-share capacity rejection."),
		sharingActive:       desc("tenant_sharing_requests_in_flight", "Reservations classified at acquisition, including brief uncommitted leases.", "allocation"),
		sharingAdmissions:   desc("tenant_sharing_admissions_total", "Successful service admissions by tenant allocation class.", "allocation"),
		resolutions:         desc("priority_resolutions_total", "Resolved configured priority and bounded source.", "priority", "source"),
		tenantLimit:         desc("tenant_concurrency_limit", "Default tenant hard cap, or configured target share when sharing is enabled."),
		tenantTracked:       desc("tenants_tracked", "Identified tenants currently retained in the bounded registry."),
		tenantTrackingLimit: desc("tenants_tracking_limit", "Maximum identified tenant entries."),
		tenantActive:        desc("tenant_requests_in_flight", "Tenant leases including brief service-admission reservations; never labeled by identity.", "bucket"),
		tenantExpired:       desc("tenant_entries_expired_total", "Inactive identified tenant entries expired."),
		controllerSamples:   desc("controller_last_window_samples", "Completed samples in the last evaluated adaptive window."),
		controllerRatio:     desc("controller_last_p90_ratio", "Bucket-estimated p90 handler duration divided by latency target in the last evaluated window."),
		controllerFailures:  desc("controller_last_failure_fraction", "Failed sample fraction in the last evaluated adaptive window."),
		controllerTime:      desc("controller_last_evaluation_timestamp_seconds", "Unix timestamp of the last adaptive evaluation; zero before evaluation."),
		controllerDecision:  desc("controller_last_decision", "Last adaptive decision, including hold and not_evaluated; bounded labels.", "decision", "reason"),
		controllerSaturated: desc("controller_last_window_saturated", "Whether saturation was observed in the last evaluated adaptive window."),
		limit:               desc("concurrency_limit", "Current admission limit."),
		minimum:             desc("concurrency_min_limit", "Configured lower admission bound."),
		maximum:             desc("concurrency_max_limit", "Configured admission ceiling."),
		reserved:            desc("concurrency_reserved_critical", "Capacity unavailable to background work."),
		active:              desc("requests_in_flight", "Currently admitted work; may exceed a reduced limit while draining.", "priority"),
		info:                desc("service_info", "Service configuration information.", "mode"),
		admitted:            desc("requests_admitted_total", "Requests admitted to handlers.", "priority"),
		rejected:            desc("requests_rejected_total", "Requests rejected before reaching handlers.", "priority", "reason"),
		completed:           desc("requests_completed_total", "Admitted requests that ended.", "priority", "outcome", "status_class"),
		duration:            desc("request_duration_seconds", "Duration of admitted handler work, excluding admission rejections.", "priority", "outcome"),
		adjustments:         desc("limit_adjustments_total", "Adaptive limit changes.", "direction", "reason"),
	}
	return registry.Register(c)
}

func (c *collector) Describe(out chan<- *prometheus.Desc) {
	c.describeQueue(out)
	for _, desc := range []*prometheus.Desc{c.controllerControlRatio, c.controllerControlFailure, c.controllerWindowInterval, c.controllerWindowStart, c.controllerProfile, c.controllerSmoothed, c.controllerPending, c.controllerSparse, c.controllerExternal, c.workAdmitted, c.workRejected, c.workCompleted, c.workDuration, c.budgetBytes, c.budgetLimit, c.budgetActive, c.budgetTracked, c.budgetTrackingLimit, c.budgetFallback, c.budgetExpired, c.budgetAttempts, c.budgetProposals, c.budgetRejected, c.budgetAdmitted, c.decisionInfo, c.proposals, c.signalState, c.signalValue, c.signalThreshold, c.signalTime, c.signalAccepted, c.signalDropped, c.signalFailures, c.sharingDemand, c.sharingShares, c.sharingPause, c.sharingActive, c.sharingAdmissions, c.resolutions, c.limit, c.minimum, c.maximum, c.reserved, c.active, c.info, c.admitted, c.rejected, c.completed, c.duration, c.adjustments, c.controllerSamples, c.controllerRatio, c.controllerFailures, c.controllerTime, c.controllerDecision, c.controllerSaturated, c.tenantLimit, c.tenantTracked, c.tenantTrackingLimit, c.tenantActive, c.tenantExpired} {
		out <- desc
	}
}

func (c *collector) Collect(out chan<- prometheus.Metric) {
	s := c.service.Statistics()
	c.collectQueue(out, s)
	gauge := func(desc *prometheus.Desc, value float64, labels ...string) {
		out <- prometheus.MustNewConstMetric(desc, prometheus.GaugeValue, value, labels...)
	}
	counter := func(desc *prometheus.Desc, value uint64, labels ...string) {
		out <- prometheus.MustNewConstMetric(desc, prometheus.CounterValue, float64(value), labels...)
	}
	for i, kind := range []string{"operation", "http"} {
		v := s.Work[i]
		counter(c.workAdmitted, v.Admitted, kind)
		counter(c.workRejected, v.Rejected, kind)
		count := uint64(0)
		for j, outcome := range []string{"success", "failed", "canceled", "panicked"} {
			counter(c.workCompleted, v.Completed[j], kind, outcome)
			count += v.Completed[j]
		}
		buckets := map[float64]uint64{}
		for j, b := range s.DurationBounds {
			buckets[b] = v.DurationBuckets[j]
		}
		out <- prometheus.MustNewConstHistogram(c.workDuration, count, v.DurationSum, buckets, kind)
	}
	if s.Decisions.Enabled {
		gauge(c.decisionInfo, 1, string(s.Decisions.Mode))
		for _, b := range s.Decisions.Budgets {
			gauge(c.budgetBytes, float64(b.ActiveWriteBytes), b.Name)
			gauge(c.budgetLimit, float64(b.MaxWriteBytes), b.Name)
			gauge(c.budgetActive, float64(b.Active), b.Name)
			gauge(c.budgetTracked, float64(b.Tracked), b.Name)
			gauge(c.budgetTrackingLimit, float64(b.TrackingLimit), b.Name)
			gauge(c.budgetFallback, float64(b.MissingActive), b.Name, "missing")
			gauge(c.budgetFallback, float64(b.OverflowActive), b.Name, "overflow")
			counter(c.budgetExpired, b.Expired, b.Name)
			counter(c.budgetAttempts, b.Attempts, b.Name)
			counter(c.budgetProposals, b.WouldReject, b.Name)
			counter(c.budgetRejected, b.Rejected, b.Name)
			counter(c.budgetAdmitted, b.Admitted, b.Name)
		}
		for i, a := range []string{"allow", "limit", "reject"} {
			counter(c.proposals, s.Decisions.Proposals[i], a)
		}
		for _, v := range s.Decisions.Signals {
			for _, state := range []string{"missing", "healthy", "pressure", "unknown", "stale"} {
				n := 0.
				if state == v.State {
					n = 1
				}
				gauge(c.signalState, n, v.Name, state)
			}
			gauge(c.signalValue, v.Value, v.Name)
			gauge(c.signalThreshold, v.Threshold, v.Name)
			at := 0.
			if !v.ObservedAt.IsZero() {
				at = float64(v.ObservedAt.UnixNano()) / 1e9
			}
			gauge(c.signalTime, at, v.Name)
			counter(c.signalAccepted, v.Accepted, v.Name)
			for i, r := range []string{"invalid", "out_of_order", "future"} {
				counter(c.signalDropped, v.Dropped[i], v.Name, r)
			}
			for i, r := range []string{"error", "timeout", "panic", "busy"} {
				counter(c.signalFailures, v.Failures[i], v.Name, r)
			}
		}
	}
	if s.Tenants.Enabled {
		t := s.Tenants
		gauge(c.tenantLimit, float64(t.MaxConcurrent))
		gauge(c.tenantTracked, float64(t.Tracked))
		gauge(c.tenantTrackingLimit, float64(t.MaxTracked))
		gauge(c.tenantActive, float64(t.IdentifiedActive), "identified")
		gauge(c.tenantActive, float64(t.MissingActive), "missing")
		gauge(c.tenantActive, float64(t.OverflowActive), "overflow")
		counter(c.tenantExpired, t.EntriesExpired)
	}
	if s.Tenants.SharingEnabled {
		t := s.Tenants
		gauge(c.sharingDemand, float64(t.DemandingTenants))
		gauge(c.sharingShares, float64(t.DemandShares))
		paused := 0.
		if t.BorrowingPaused {
			paused = 1
		}
		gauge(c.sharingPause, paused)
		for i, kind := range []string{"share", "borrowed", "fallback"} {
			active := t.IdentifiedActive - t.BorrowedActive
			if i == 1 {
				active = t.BorrowedActive
			}
			if i == 2 {
				active = t.MissingActive + t.OverflowActive
			}
			gauge(c.sharingActive, float64(active), kind)
			counter(c.sharingAdmissions, s.TenantAllocations[i], kind)
		}
	}
	if s.Controller.Enabled {
		e := s.Controller
		gauge(c.controllerSamples, float64(e.Samples))
		gauge(c.controllerRatio, e.P90Ratio)
		gauge(c.controllerFailures, e.FailureFraction)
		timestamp := 0.0
		if !e.EvaluatedAt.IsZero() {
			timestamp = float64(e.EvaluatedAt.UnixNano()) / 1e9
		}
		gauge(c.controllerTime, timestamp)
		gauge(c.controllerDecision, 1, e.Decision, e.Reason)
		gauge(c.controllerControlRatio, e.ControlRatio)
		gauge(c.controllerControlFailure, e.ControlFailureFraction)
		gauge(c.controllerWindowInterval, e.WindowInterval.Seconds())
		windowStart := 0.0
		if !e.WindowStartedAt.IsZero() {
			windowStart = float64(e.WindowStartedAt.UnixNano()) / 1e9
		}
		gauge(c.controllerWindowStart, windowStart)
		gauge(c.controllerProfile, 1, e.Profile)
		gauge(c.controllerSmoothed, e.SmoothedControlRatio)
		gauge(c.controllerPending, float64(e.PendingSamples))
		sparse, external := 0.0, 0.0
		if e.SparseWindow {
			sparse = 1
		}
		if e.ExternalLimit {
			external = 1
		}
		gauge(c.controllerSparse, sparse)
		gauge(c.controllerExternal, external)
		saturated := 0.0
		if e.Saturated {
			saturated = 1
		}
		gauge(c.controllerSaturated, saturated)
	}
	gauge(c.limit, float64(s.State.Limit))
	gauge(c.minimum, float64(s.State.MinConcurrent))
	gauge(c.maximum, float64(s.State.MaxConcurrent))
	gauge(c.reserved, float64(s.State.ReservedCritical))
	gauge(c.info, 1, s.State.Mode)
	for p, n := range s.TierActive {
		gauge(c.active, float64(n), string(p))
	}
	if s.PriorityEnabled {
		for _, v := range s.Resolutions {
			counter(c.resolutions, v.Count, string(v.Priority), v.Source)
		}
	}
	classes := [7]string{"1xx", "2xx", "3xx", "4xx", "5xx", "other", "none"}
	for _, p := range s.Tiers {
		priority := string(p.Priority)
		if s.Queue.Enabled {
			for i, r := range []string{"queue_full", "queue_reserved", "queue_timeout", "queue_deadline", "queue_canceled"} {
				counter(c.rejected, p.RejectedQueue[i], priority, r)
			}
		}
		counter(c.admitted, p.Admitted, priority)
		if s.PriorityEnabled {
			for _, v := range []struct {
				reason string
				n      uint64
			}{{"tier_capacity_reserved", p.RejectedTier}, {"cohort_limited", p.RejectedCohort}, {"priority_metadata_invalid", p.RejectedPriorityInvalid}, {"priority_metadata_untrusted", p.RejectedPriorityUntrusted}} {
				counter(c.rejected, v.n, priority, v.reason)
			}
		}
		if s.Decisions.Enabled {
			for i, r := range []string{"write_bytes_limit", "hot_key_limit", "resource_key_registry_full", "resource_cost_missing", "resource_key_missing", "resource_metadata_invalid", "resource_metadata_untrusted", "resource_accounting_exhausted"} {
				counter(c.rejected, p.RejectedResources[i], priority, r)
			}
			for i, r := range []string{"signal_pressure", "signal_unavailable", "signal_concurrency_limit"} {
				counter(c.rejected, p.RejectedSignals[i], priority, r)
			}
		}
		counter(c.rejected, p.RejectedConcurrency, priority, "concurrency_limit")
		counter(c.rejected, p.RejectedReservation, priority, "critical_capacity_reserved")
		if s.Tenants.SharingEnabled {
			counter(c.rejected, p.RejectedTenantShare, priority, "tenant_share_reserved")
		}
		if s.Tenants.Enabled {
			for _, v := range []struct {
				reason string
				n      uint64
			}{{"tenant_concurrency_limit", p.RejectedTenant}, {"tenant_registry_full", p.RejectedTenantRegistry}, {"tenant_identity_missing", p.RejectedTenantMissing}, {"tenant_identity_invalid", p.RejectedTenantInvalid}, {"tenant_identity_untrusted", p.RejectedTenantUntrusted}} {
				counter(c.rejected, v.n, priority, v.reason)
			}
		}
		for oi, o := range p.Outcomes {
			if oi == 0 {
				for i := 0; i < 6; i++ {
					counter(c.completed, o.StatusClasses[i], priority, o.Outcome, classes[i])
				}
			} else {
				counter(c.completed, o.StatusClasses[6], priority, o.Outcome, "none")
			}
			buckets := make(map[float64]uint64, len(s.DurationBounds))
			for i, bound := range s.DurationBounds {
				buckets[bound] = o.DurationBuckets[i]
			}
			out <- prometheus.MustNewConstHistogram(c.duration, o.Count, o.DurationSum, buckets, priority, o.Outcome)
		}
	}
	reasons := [3]string{"latency_pressure", "server_errors", "healthy_saturation"}
	for direction, counts := range s.Adjustments {
		label := "decrease"
		if direction == 1 {
			label = "increase"
		}
		for i, count := range counts {
			counter(c.adjustments, count, label, reasons[i])
		}
	}
}
