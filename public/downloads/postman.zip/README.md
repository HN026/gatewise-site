# Commerce Postman checks

Start `python3 run.py --profile proxy-adaptive` from the extracted example. Import Commerce.postman_collection.json and the generated environment path printed by the launcher. Run all requests in order against a fresh launch, with request timeout 5s and script timeout 15s. The launcher supports direct, proxy-fixed, proxy-adaptive, middleware-fixed and middleware-adaptive. The expected_mode variable matches the chosen mode. Tests use only disposable local data and loopback control listeners. The full collection restores fault controls. To repeat cleanly, stop and relaunch the example. `python3 run.py --verify` runs the same portable collection with an installed Postman CLI.

For tenant-isolation checks, launch with `--tenants` and import Tenants.postman_collection.json instead. It requires the example cap 2 / tracking bound 32 / TTL 2s and synthetic loopback X-Demo-Tenant identities. The expiry request waits 2.3 seconds; keep script timeout at 15 seconds or more. The original Commerce collection runs with tenant isolation disabled.

Use `Priorities.postman_collection.json` with `run.py --priorities`. It checks server defaults, trusted overrides, downstream importance/cohorts, malformed metadata, compatibility mappings and bounded metric labels. Trust is loopback-only in this example; remote forgery and forwarded-IP spoofing are covered by Go integration tests.

`python3 validate_priority.py --output results/priority-validation.json` exercises trusted and untrusted orders entries during downstream SQL pressure. It preserves trust on the internal proxy-to-backend hop and checks that forged forwarding headers do not promote a caller.

For sharing, use `Sharing.postman_collection.json` against `run.py --sharing 4`. It extends the tenant contract with borrowed-admission headers and sharing metrics. The 4-request ceiling includes the configured 2-request share.

`python3 validate_sharing.py --output results/sharing-validation.json` checks returning customers while borrowed requests are still running. This targeted test retries 503 every 10ms (up to 3s); the separate scheduled throughput experiment never retries.

Use `Signals.postman_collection.json` with `run.py --decisions enforce` or `--decisions observe`. The generated environment selects the expected mode. Run in order; allow script timeout 15 seconds. It verifies conflicting signals, stale/unknown observations, provider errors/timeouts, recovery, mode ownership and metrics against the real services. These loopback providers are controlled test inputs, not automatic database or runtime sensors. `python3 decision_benchmark.py --output results/decision-results.json` compares disabled, observe and enforce modes, with no retries.

Use `Resources.postman_collection.json` with `run.py --resources enforce`, `observe` or `disabled`. It checks actual memory/goroutine measurements, healthy allocation/fanout, persisted logical writes, concurrent byte/key protection, unrelated SQL reads, metadata mismatch, aggregate metrics and cleanup. The demo treats loopback clients as trusted planners; it is not authentication. Script timeout 15s and request timeout 5s cover the concurrent key test. `resource_benchmark.py` separately measures actual pressure and unrelated probes with no retries.

Use `Operations.postman_collection.json` with `run.py --operations disabled`, `fixed`, `pool` or `balanced`. It checks SQL/worker lifetimes, bounded admission, stream cleanup, transaction cancellation, physical-standby behavior and real pool contention/recovery. These checks require the launcher's isolated primary and standby databases.

For the stable adaptive controller, launch `python3 run.py --profile middleware-adaptive --controller-profile stable --decisions enforce`, or select `proxy-adaptive`. Import `Adaptive.postman_collection.json` and the generated environment. Run in order against a fresh launch, with request timeout 5s and script timeout 15s. It verifies profile headers, bounded controller metrics, injected server-error feedback, a sparse hold, a binding signal cap and recovery. The collection restores controls. Without `--decisions enforce`, signal-specific checks are skipped. `--verify` selects this collection automatically when the stable profile is selected. Legacy defaults remain available with `--controller-profile legacy`; the original Commerce collection covers that configuration. Controlled signals do not automatically detect resource pressure.

For bounded waiting, use `python3 run.py --queue --profile middleware-fixed`, or select a proxy/fixed/adaptive profile. Import `Queue.postman_collection.json` and the generated environment; run in order with a 5s request timeout and 15s script timeout. It exercises full/expired waiting, successful delayed admission, waiting-slot reservations, retained streaming for a large body, and SQL cleanup. The example queue is 16 waiting requests, 40ms maximum wait, 20ms aging and 4 critical waiting slots. These are example values. Caller cancellation is separately exercised with real 20ms HTTP client deadlines in `queue_benchmark.py`; CLI assertions do not claim to abort client requests.

## Independent reference policies

`Reference.postman_collection.json` uses the environment printed by `run.py --profile semaphore --max-concurrent 4` or `run.py --profile rate --rate-per-second 1 --rate-burst 1`. It runs 20 concurrent checkouts against isolated local data, verifies explicit reference refusals, execution accounting and cleanup, then restores healthy SQL. These policies are demo references, not Gatewise library APIs. `--verify` chooses this collection automatically for those two profiles.

For the fixed open-loop policy comparison, use `python3 comparison_benchmark.py --output results/comparison-results.json`. Postman assertions are functional checks; the Go load generator measures overload independently so refused traffic does not reduce the offered rate.

## v0.11.1 cancellation controls and containers

`Cancellation.postman_collection.json` verifies the loopback fixture control, a normal committed checkout, SQL cleanup and resetting cancellation behavior. It does not claim to force a caller timeout. Use `python3 cancellation_check.py` for actual 40 ms client deadlines against 300 ms SQL work in middleware/proxy modes. The ignored-cancellation fixture retains the one-second SQL timeout.

Use `python3 hardening_benchmark.py` for the seeded policy/reservation matrix. Each policy gets identical per-seed request plans; the report stores their hashes. For a locally built Podman image, `python3 container_check.py --image localhost/gatewise:v0.11.1` runs the existing Commerce collection through the non-root proxy with real PostgreSQL, validates configuration and checks SIGTERM shutdown. Docker users can pass `--engine docker --image gatewise:v0.11.1`.
